# Trauma Star — Protocols & Dosages

Monroe County Fire Rescue Trauma Star. Protocols, dose calculators, pediatric
tape, burns, RSI, ventilator, destinations and the flight checklists, in one
page that works with no signal.

**DRAFT PAGES ARE NOT APPROVED.** Anything tagged *Draft — not approved* is
written for the Medical Director's review and is not to be worked from.

## Put it on a phone or iPad

1. Open the GitHub Pages link in **Safari** (iPhone/iPad) or **Chrome** (Android).
2. Let it finish loading once while you have signal — that is when it caches itself.
3. Share → **Add to Home Screen**.
4. It now opens full screen, with the Trauma Star icon, and works in the aircraft
   with no signal at all.

## Turning on GitHub Pages

Repository → **Settings** → **Pages** → Source: *Deploy from a branch*,
Branch: `main`, folder: `/ (root)` → Save. The link appears on that page a
minute later.

## Updating it

Replace `index.html`, then change the `CACHE` version string at the top of
`sw.js` (any new value will do). Phones pick the new version up the next time
they open the app with signal.

## What is in here

| File | What it is |
|---|---|
| `index.html` | The whole app — protocols, drugs, calculators, images. One file. |
| `sw.js` | Service worker. Caches the app so it opens offline. |
| `manifest.webmanifest` | Name, colours and icons for the home-screen app. |
| `icons/` | The Trauma Star icon at 180, 192 and 512 px. |

Sources are listed inside the app, on the **Sources** tab: printed page numbers
are the 2025 MCFR EMS Protocols V4.2 and the current Medication Formulary;
anything else is marked PROGRAM, REFERENCE or DRAFT.
